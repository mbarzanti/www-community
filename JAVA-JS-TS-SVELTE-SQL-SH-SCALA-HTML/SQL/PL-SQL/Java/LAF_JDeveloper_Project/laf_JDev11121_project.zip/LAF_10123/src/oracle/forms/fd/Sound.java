package oracle.forms.fd;

import java.applet.Applet;
import java.applet.AudioClip;
import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.net.URL;
import java.net.MalformedURLException;
import javax.swing.JApplet;
import oracle.forms.ui.VBean;
import oracle.forms.properties.ID;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Method;

import sun.misc.BASE64Decoder;

  /**
   * A javabean that stores and plays sound files
   * like : .WAV  .AU  .MID  .AIFF
   *
   * @author Francois Degrelle
   * @version 1.3
   * 
   * July      2008  - add the PLAY_SOUND_LOOP
   *                   STOP_SOUND, REMOVE_SOUND
   *                   and REMOVE_ALL_SOUNDS methods
   * January   2009  - add the MP3 reading feature
   *                   (needs to download and copy jl1.0.jar file (JLayer 1.0)
   *                   http://prdownloads.sourceforge.net/javalayer/jlayer1.0.zip?download)
   */

public class Sound extends VBean {
    public final static ID psetSoundFile   = ID.registerProperty("SET_SOUND_FILE");  
    public final static ID psetSoundBase   = ID.registerProperty("SET_SOUND_BASE");      
    public final static ID pSoundplay      = ID.registerProperty("PLAY_SOUND");  
    public final static ID pSoundplayLoop  = ID.registerProperty("PLAY_SOUND_LOOP");  
    public final static ID pSoundStop      = ID.registerProperty("STOP_SOUND");  
    public final static ID pSoundRemove    = ID.registerProperty("REMOVE_SOUND");      
    public final static ID pSoundRemoveAll = ID.registerProperty("REMOVE_ALL_SOUNDS");      
    public final static ID pSoundLog       = ID.registerProperty("SET_LOG");          
    SoundList soundList;
    String soundFile;
        
    AudioClip Clip ;
    URL codeBase;
    MP3 mp3 = null ;//new MP3(); 
    public static List  sounds    = new ArrayList(10) ;
    public static List  soundsMP3 = new ArrayList(10) ;
    private StringBuffer sbSound  = new StringBuffer();    
    private Object player; 
    boolean bLog = false ;

    public Sound() 
    {             
    }

  public boolean setProperty(ID property, Object value)
  {
    /*----------------------*
     *  load the sound file 
     *----------------------*/
    if (property == psetSoundFile) 
    {
      String sValue="", sDir="", sFile="" ;
      sValue = value.toString() ;
      StringTokenizer st ;
      st = new StringTokenizer(sValue,",");      
      if (st.hasMoreTokens()) sDir = st.nextToken() ; 
      else return false ;
      if(!sDir.equals("/")) 
      {
         try {
           codeBase = new URL("file:" + sDir + "/");
         } catch (MalformedURLException e) {
           System.err.println(e.getMessage());
         }
      }
       // create the sound list
       if(soundList == null) 
       {
         if(!sDir.equals("/")) soundList = new SoundList(codeBase);
         else soundList = new SoundList();
       }
       while(st.hasMoreTokens())
       {
         soundFile = st.nextToken() ;
         // add sound to the Hash Table
         // if it does not exist
         for (int i = 0; i< sounds.size(); i++){
            String sSound = (String)sounds.get(i);
            if(sSound.equalsIgnoreCase(soundFile)) return false;
         }
         sounds.add(soundFile);
         log("add sound file:"+soundFile);
         if(soundFile.indexOf(".mp3") > -1)
         {
           if(mp3 == null) mp3 = new MP3(); 
           mp3.load(sDir + "/" + soundFile, soundFile);
         }
         else
         {
           if(!sDir.equals("/")) soundList.startLoading(codeBase, soundFile);
           else soundList.startLoading(soundFile);
         }
       }
       
      return true ;
    }
    
      /*-------------------------------*
       *  get the sound from database
       *-------------------------------*/
      if(property == psetSoundBase)
      {
        log("setSoundBase");
        String s = (String)value ;
        String sName="", sContent="";
        StringTokenizer st = new StringTokenizer(s,"|");
        if (st.hasMoreTokens()) sContent = st.nextToken() ;        
        if (st.hasMoreTokens()) sName  = st.nextToken() ;        
         if( ! sContent.equalsIgnoreCase("[END_SOUND]"))
          {
            sbSound.append(sContent) ;
          }
          else
          {
            BASE64Decoder decoder = new BASE64Decoder();
            try{
              byte[] decodedStr = decoder.decodeBuffer(sbSound.toString());
              //BufferedInputStream stream = new BufferedInputStream(new ByteArrayInputStream(decodedStr));

              // add sound to the Hash Table
              // if it does not exist
              for (int i = 0; i< sounds.size(); i++){
                 String sSound = (String)sounds.get(i);
                 if(sSound.equalsIgnoreCase(sName)) return false;
              }
              sounds.add(sName);
              log("add sound file (base):"+sName);
              if(sName.indexOf(".mp3") > -1)
              {
                if(mp3 == null) mp3 = new MP3(); 
                BufferedInputStream stream = new BufferedInputStream(new ByteArrayInputStream(decodedStr));
                mp3.load(sName, stream);
              }
              else {
                  FileOutputStream fos = new FileOutputStream(sName);
                  fos.write(decodedStr);
                  fos.close();
                  soundList.startLoading(sName);
              }
            } catch(Exception e){;}
            finally{ sbSound = new StringBuffer(); }
          }            
        return true ;
      }
      
    /*----------------------------------*
     *  play a sound from the soundlist
     *----------------------------------*/
    else if (property == pSoundplay)
    {
      String sValue = value.toString() ;
      log("play sound:"+sValue);
      // stop current clip
      if(player != null) InvokeMethod(player, "close");
      if( Clip != null ) Clip.stop();      
      
      if(sValue.indexOf(".mp3") > -1)
      {
          for (int i = 0; i< soundsMP3.size(); i++){
            soundMP3 smp3 = (soundMP3) soundsMP3.get(i);
            if(smp3.sName.equalsIgnoreCase(sValue))
            {
              mp3.play(i);
              break ;
            }
         }
      }
      else
      {
        // start new clip
        Clip = soundList.getClip(sValue);
         if( Clip != null )
         {
           Clip.play(); 
         }
         else
         {
           System.out.println("*!! L&F Sound - " + sValue+ " not loaded !!*");
         }
      }
      return true ;
    }
    
    /*-----------------------------*
     *   play a sound in a loop
     *-----------------------------*/
    else if (property == pSoundplayLoop)
    {
      String sValue = value.toString() ;
      log("play sound loop:"+sValue);
      Clip = soundList.getClip(sValue);
       if( Clip != null )
       {
         Clip.loop(); 
       }
       else
       {
         System.out.println("*!! L&F Sound - " + sValue+ " not loaded !!*");
       }
      return true ;
    }
    
    /*-----------------------------*
     *     stop playing a sound
     *-----------------------------*/
    else if (property == pSoundStop)
    {
      String sValue = value.toString() ;
      log("stop sound:"+sValue);
      Clip = soundList.getClip(sValue);
      if(player != null) InvokeMethod(player, "close");
      /*
      if(sValue.indexOf(".mp3") > -1)
      {
        if(player != null) InvokeMethod(player, "close");
      }
      */
      else
      {
         if( Clip != null )
         {
           Clip.stop();
         }
         else
         {
           System.out.println("*!! L&F Sound - " + sValue+ " not loaded !!*");
         }
      } 
      return true ;
    }

    
    /*---------------------------------*
     *   remove a sound from the list
     *---------------------------------*/
    else if (property == pSoundRemove)
    {
      String sValue = value.toString() ;
      log("remove sound:"+sValue);
      try{
        if(sValue.indexOf(".mp3") > -1) soundsMP3.remove(sValue) ;
        soundList.remove(sValue) ;
      }  
      catch(Exception ex) {System.out.println("*!! L&F Sound - " + sValue+ " unable to remove !!*");}
      return true ;
    }
    
    /*------------------------------------*
     *   remove all sounds from the list
     *------------------------------------*/
    else if (property == pSoundRemoveAll)
    {
      log("remove all sounds");
      try{
        sounds.clear();
        soundList.clear();
        soundsMP3.clear();
      }  
      catch(Exception ex) {System.out.println("*!! L&F Sound - unable to clear the list !!*");}
      return true ;
    }
    
    /*-----------------------------*
     *   set LOG
     *-----------------------------*/
    else if (property == pSoundLog)
    {
      String sValue = value.toString() ;
      if(sValue.equalsIgnoreCase("true")) bLog = true ;
      else bLog = false ;
      return true ;
    }
    
    else
    {
     return super.setProperty(property, value);
    }
  }
  

    /*------------------------------------------------------------------------*
     * Loads and holds a bunch of audio files whose locations are specified
     * relative to a fixed base URL.
     *-----------------------------------------------------------------------*/
    class SoundList extends java.util.Hashtable {
        JApplet applet;
        URL baseURL;

        public SoundList() { super(1); }
        public SoundList(URL baseURL) {
            super(1); 
            this.baseURL = baseURL;
        }

        public void startLoading(String relativeURL) {
            new SoundLoader(this, baseURL, relativeURL);
        }

        public void startLoading(URL baseUrl, String relativeURL) {
            new SoundLoader(this, baseUrl, relativeURL);
        }
        
        public AudioClip getClip(String relativeURL) {
            return (AudioClip)get(relativeURL);
        }

        public void putClip(AudioClip clip, String relativeURL) {
            put(relativeURL, clip);
        }
    }
    
    class SoundLoader  {
        SoundList soundList;
        URL completeURL;
        String relativeURL, sURL;
        AudioClip audioClip;

        public SoundLoader(SoundList soundList,
                           URL baseURL, String relativeURL) {
            this.soundList = soundList;
            this.relativeURL = relativeURL;
            sURL = "/" + relativeURL ;
            completeURL = getClass().getResource(sURL) ;
            if(completeURL != null)
            {
               audioClip = Applet.newAudioClip(completeURL);
            }
            else
            {
             //System.out.println("* L&F Sound - read :"+relativeURL+" from disk");
              try {
                  completeURL = new URL(baseURL, relativeURL);
                  audioClip = Applet.newAudioClip(completeURL);
              } catch (MalformedURLException e){
                  System.err.println("*!! L&F Sound -  "+e.getMessage() + " !!*");
              }            

            }
            if(audioClip != null) soundList.putClip(audioClip, relativeURL);        
            else System.out.println("*!! L&F Sound -  :"+relativeURL+" not loaded !!*");
            
        }

    }

    // object to store MP3 properties
    class soundMP3 extends Object
    {
       String               sName = "" ;
       String               sFullName = "" ;
       BufferedInputStream  bis = null ;
       
       soundMP3( String p_name, String p_fullname, BufferedInputStream p_bis)
       {
         sName = p_name ;
         sFullName = p_fullname ;
         bis   = p_bis ;
       }
    }
    
    
    /*-------------------------------------------------------------------------*
     *  class to read MP3 files
     *  uses the JLayer 1.0 feature
     *    http://www.javazoom.net/javalayer/sources.html
     *  download page:
     *    http://prdownloads.sourceforge.net/javalayer/jlayer1.0.zip?download
     *-------------------------------------------------------------------------*/
    class MP3 {
    private String filename;

    // constructor that takes the name of an MP3 file
    public MP3() {}
    public MP3(String filename) {
        this.filename = filename;
    }

    public void close() 
    { 
      if(player != null) InvokeMethod(player, "close");
    }
    
    // read the MP3 file
    public void load(String filename, String name) {
        try {
            
            byte[] b = null ;
            FileInputStream fis     = new FileInputStream(filename);
            BufferedInputStream bis = new BufferedInputStream(fis);
            soundMP3 smp3 = new soundMP3(name,filename,bis);
            soundsMP3.add(smp3);
        }
        catch (Exception e) {
            System.out.println("Problem loading file " + filename);
            System.out.println(e);
        }        
    }
      // read the MP3 from database
      public void load(String name, BufferedInputStream bis) {
          try {
              soundMP3 smp3 = new soundMP3(name, name, bis);
              soundsMP3.add(smp3);
          }
          catch (Exception e) {
              System.out.println("Problem loading file " + filename);
              System.out.println(e);
          }        
      }    
    // play the MP3 file to the sound card
    public void play(int iNumber) {
        try {
            soundMP3 smp3 = (soundMP3) soundsMP3.get(iNumber);
            if(smp3 != null) 
            {
              try{
                if(player != null) InvokeMethod(player, "close");
                try {
                      Class.forName("javazoom.jl.player.Player");
                      player = new javazoom.jl.player.Player(smp3.bis);
                } catch (ClassNotFoundException e) {
                          System.out.println("L&F Sound error : Class not found\n   ==>install the j1.0.jar file in the class path");
                          return ;
                }
              }
              catch(Exception ex) {System.out.println("Playing MP3 error:"+ex.toString());}
            }  
        }
        catch (Exception e) {
            System.out.println("Problem playing file ");
            System.out.println(e);
        }        
        // run in new thread to play in background
        new Thread() {
            public void run() {
                InvokeMethod(player, "play");
            }
        }.start();

    }    
  }
  
  /*
   *  internal function to invoke methods
   *  of the javazoom.jl.player.Player class
   */
  void InvokeMethod(Object obj, String sMethodName) {
      log("InvokeMethod():"+sMethodName);
      try{
        Class[] types = new Class[] {};
        Method method = obj.getClass().getMethod(sMethodName, types);
        method = obj.getClass().getMethod(sMethodName, types);
        method.invoke(obj,null);
        log("InvokeMethod():"+sMethodName+" OK");
      }
      catch(NoSuchMethodException e){;}
      catch(java.lang.reflect.InvocationTargetException e){;}
      catch(java.lang.IllegalAccessException e){;}      
  }
  
  public void log( String sMessage )
  {
    if( bLog) System.out.println( "L&F Sound : " + sMessage ) ;
  }   
  
}


